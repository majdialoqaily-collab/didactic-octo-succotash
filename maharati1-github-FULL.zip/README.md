# تطبيق المهارات الرقمية - maharati1
## وزارة التربية والتعليم - الأردن
### تصميم المعلم مجدي العقيلي

**الرابط الحي:** https://maharati1.netlify.app  
**البريد:** MAJDIALOQAILY@GMAIL.COM  
**الهاتف:** 00962770183434

---

## 📚 وصف المشروع

منصة تعليمية مجانية لمادة المهارات الرقمية للصفوف:
- سابع، ثامن، تاسع، عاشر، أول ثانوي أكاديمي، ثاني ثانوي

تحل مشكلة منصة Site123 المدفوعة وتوفر بديل مجاني 100% على Netlify.

## ✨ المميزات الحالية (النسخة الآمنة)

### للمعلم:
- تسجيل بحقول إلزامية: الاسم، الإيميل، الرقم الوزاري، الهاتف، المدرسة، الصفوف التي يدرسها
- لوحة تحكم تعرض فقط الصفوف التي يدرسها
- إضافة مهام مع علامة منفصلة
- رفع ملفات Word/Excel/صور/مخططات
- **ميزة الجداول الآمنة:** زر + إدراج جدول + مساعد لصق من Word/Excel (external overlay - لا يكسر React)
- تصحيح تلقائي فوري مع تقدير (ممتاز، جيد جداً...)
- تصدير علامات الطلاب إلى Excel
- نظام طلب إعادة المحاولة من الطالب
- عداد وقت اختبار 90 دقيقة (external safe)
- مطابقة ذكية لاسم المدرسة حتى لو مختلف قليلاً

### للطالب:
- تسجيل: الاسم، الإيميل، الرقم الوطني 10 أرقام، الصف، المدرسة، المجال المهني للثاني ثانوي
- لوحة تحكم تعرض مهام معلمي نفس المدرسة والصف فقط
- أدوات مساعدة: Microsoft Office, سيراج AI, Canva, Meta AI, CreateAI, ChatlyAI, Word Cloud, HTML, Python Coddy, Excel
- إنهاء وإرسال مع تصحيح فوري
- سجل علاماتي
- عداد 90 دقيقة يبدأ تلقائياً + تنبيهات 15/5/1 دقيقة
- لا يمكن إعادة المحاولة إلا بموافقة المعلم

### التقني:
- تصميم داكن #1E293B / #334155 (مطلوب من المستخدم)
- Google AdSense: ca-pub-6648906452075318 + إعلانين في الرئيسية مخفية خلفية
- لا يظهر اسم المدرسة في الرئيسية - فقط بعد تسجيل الدخول
- حفظ في localStorage + database
- بدون إظهار أكواد HTML خارجية (تم إصلاح مشكلة container1/container2)

## 📁 هيكل المشروع

```
maharati1-github/
├── index.html (الملف الرئيسي الآمن مع الميزات)
├── index-pure-clean-backup.html (نسخة احتياطية نظيفة 100% بدون ميزات إضافية)
├── assets/
│   ├── qr_maharati1.png (QR أزرق)
│   ├── qr_maharati1_simple.png (QR أسود للطباعة)
│   ├── qr_maharati1_card.png (كرت تعليمات مع QR)
│   └── qr_maharati1.svg (SVG للطباعة الكبيرة)
├── guides/
│   ├── teacher-guide.html (دليل المعلم المفصل)
│   └── student-guide.html (دليل الطالب المفصل)
├── README.md
└── .gitignore
```

## 🚀 طريقة الرفع إلى GitHub (خطوة بخطوة)

### الطريقة 1: عبر موقع GitHub (سهلة - بدون أوامر)

1. ادخل https://github.com/new
2. اسم المستودع: `maharati1` أو `digital-skills-app`
3. اختر Public
4. اضغط Create repository
5. اضغط "uploading an existing file"
6. اسحب ملف `index.html` من هذا المجلد
7. اضغط Commit
8. فعل GitHub Pages: Settings > Pages > Source: main branch / root > Save
9. سيصبح رابطك: `https://USERNAME.github.io/maharati1/`

### الطريقة 2: عبر Git (للمطورين)

```bash
git init
git add .
git commit -m "تطبيق المهارات الرقمية - النسخة الآمنة مع الجداول والعداد"
git branch -M main
git remote add origin https://github.com/USERNAME/maharati1.git
git push -u origin main
```

## 🌐 الربط مع Netlify (الحالي)

الموقع الحالي على Netlify:
1. https://app.netlify.com/sites/maharati1/deploys
2. اسحب index.html
3. سيتحدث تلقائياً https://maharati1.netlify.app

يمكنك ربط GitHub بـ Netlify ليتم التحديث تلقائياً:
Netlify > Site settings > Build & deploy > Connect to Git

## 🔒 الأمان - لماذا هذه النسخة آمنة؟

- جميع الميزات الجديدة (الجداول + العداد) كـ **external overlay** خارج كود React
- لا تعديل داخل bundle React نفسه - يمنع الصفحة البيضاء
- تم اختبار: `outside <script>` لا يحتوي على `studentName` أو `container1`
- تم إخفاء أكواد AdSense داخل wrapper لا تظهر كنص

## ⚠️ ملاحظة عن ميزة الجداول

حالياً: عند لصق جدول من Word، يظهر ككود HTML (وسوم). هذا معروف.
**الخطة بعد انتهاء الطلاب من الإجابات الحالية:**
- إعادة تركيب محرر Rich Text حقيقي (contenteditable div) بدلاً من textarea
- مع أزرار تنسيق وجدول حقيقي WYSIWYG
- بطريقة آمنة خارج React

لا تعدل الآن حتى ينتهي جميع الطلبة.

## 📄 الترخيص وحقوق النشر

```
تم تصميم هذا التطبيق من قبل المعلم مجدي العقيلي
MAJDIALOQAILY@GMAIL.COM - 00962770183434
حقوق النشر محفوظة - وزارة التربية والتعليم الأردن
```

## 🔄 النسخ الاحتياطية

- `index.html` = النسخة الحالية الآمنة مع الميزات (215KB)
- `index-pure-clean-backup.html` = نسخة نظيفة 100% تعمل دائماً (203KB) - استخدمها إذا حدثت مشكلة

## 📞 الدعم

للتواصل: MAJDIALOQAILY@GMAIL.COM

---
**آخر تحديث:** نوفمبر 2024 - النسخة الآمنة v4.1
