#!/bin/bash
echo "========================================"
echo " تصدير تطبيق المهارات الرقمية الى GitHub"
echo " المعلم مجدي العقيلي - maharati1"
echo "========================================"
echo ""

# Check git
if ! command -v git &> /dev/null; then
  echo "[خطأ] Git غير مثبت!"
  echo "Mac: brew install git"
  echo "Linux: sudo apt install git"
  exit 1
fi

echo "[1/5] تهيئة المستودع..."
git init
git add .
git commit -m "تطبيق المهارات الرقمية - النسخة الآمنة v4.1 - مع الجداول والعداد"

echo ""
read -p "ادخل رابط مستودع GitHub (مثال: https://github.com/USERNAME/maharati1.git): " REPO_URL

if [ -z "$REPO_URL" ]; then
  echo "لم تدخل رابط!"
  exit 1
fi

echo "[2/5] ربط المستودع..."
git branch -M main
git remote remove origin 2>/dev/null
git remote add origin $REPO_URL

echo "[3/5] رفع الكود الى GitHub..."
git push -u origin main

echo ""
echo "========================================"
echo " تم الرفع بنجاح! 🎉"
echo " فعل GitHub Pages من:"
echo " Settings > Pages > Branch: main > Save"
echo "========================================"
echo " رابط موقعك: https://USERNAME.github.io/maharati1/"
echo "========================================"
