@echo off
echo ========================================
echo  تصدير تطبيق المهارات الرقمية الى GitHub
echo  المعلم مجدي العقيلي - maharati1
echo ========================================
echo.

REM Check git
git --version >nul 2>&1
if errorlevel 1 (
  echo [خطأ] Git غير مثبت! حمله من: https://git-scm.com/download/win
  pause
  exit /b
)

echo [1/5] تهيئة المستودع...
git init
git add .
git commit -m "تطبيق المهارات الرقمية - النسخة الآمنة v4.1 - مع الجداول والعداد"

echo.
set /p REPO_URL=ادخل رابط مستودع GitHub الخاص بك (مثال: https://github.com/USERNAME/maharati1.git): 

if "%REPO_URL%"=="" (
  echo لم تدخل رابط! 
  pause
  exit /b
)

echo [2/5] ربط المستودع...
git branch -M main
git remote remove origin 2>nul
git remote add origin %REPO_URL%

echo [3/5] رفع الكود الى GitHub...
git push -u origin main

echo.
echo ========================================
echo  تم الرفع بنجاح! 🎉
echo  فعل GitHub Pages من:
echo  Settings ^> Pages ^> Branch: main ^> Save
echo ========================================
echo  رابط موقعك سيكون:
echo  https://USERNAME.github.io/maharati1/
echo ========================================
pause
